#wrap_rmvhyperconst_caller <- function(nn, n, k) {
#    return(wrap_rmvhyperconst(nn, n, k))
#}