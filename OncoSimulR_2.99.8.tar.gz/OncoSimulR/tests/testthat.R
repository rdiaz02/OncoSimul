library(testthat)
library(OncoSimulR)

test_check("OncoSimulR")
